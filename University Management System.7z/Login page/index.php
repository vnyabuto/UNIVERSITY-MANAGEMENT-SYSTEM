<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('Account creation.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #333;
            font-family: Arial, sans-serif;
            opacity: 0;
            transition: opacity 2s;
        }

        .container {
            width: 50%;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px #aaa;
            text-align: center;
            background: rgba(255, 255, 255, 0.8);
            transform: scale(0.9);
            transition: transform 1s;
        }

        .container:hover {
            transform: scale(1);
        }

        .btn {
            padding: 10px 20px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn:hover {
            transform: translateY(-5px);
        }

        .signup-btn {
            background-color: #28a745;
        }

        .signup-btn:hover {
            background-color: #218838;
        }

        .login-btn {
            background-color: #007bff;
        }

        .login-btn:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '1';
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>Welcome to the School Website</h1>
        <p>
            You can create an account if you do not have one or log in if you already have an account.
        </p>
        <p>
            Please select your role during sign-up and follow the necessary guidelines to complete the setup. Good luck!
        </p>
        <a href="signup.php" class="btn signup-btn">Sign Up</a>
        <a href="login.php" class="btn login-btn">Login</a>
    </div>
</body>
</html>
